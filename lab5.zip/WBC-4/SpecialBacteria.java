import greenfoot.*;  

/**
 * SpecialBacteria float along in the bloodstream. They are worth additional points and don't
 * penalize the player if they are missed. They also move slightly slower.
 * 
 * @author (of Bacteria.class) Michael Kölling
 * @version 1.0
 * Modified by Augustus Bohn
 */
public class SpecialBacteria extends Actor
{
    private int speed;

    /**
     * Constructor: Initialise the speed to a somewhat random value.
     */
    public SpecialBacteria()
    {
        speed = Greenfoot.getRandomNumber(4) + 1;
    }
    
    /**
     * Float along the bloodstream, slowly rotating.
     */
    public void act() 
    {
        setLocation(getX()-speed, getY());
        turn(1);
        
        if (getX() == 0) 
        {
            Bloodstream bloodstream = (Bloodstream)getWorld();
            bloodstream.addScore(0);
            bloodstream.removeObject(this);
        }
    }
    
}
